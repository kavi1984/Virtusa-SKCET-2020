package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirtusaLoginpageApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtusaLoginpageApplication.class, args);
	}

}
