/**
 * 
 */
package com.dts.ccec.model;

/**
 * @author dts0801010
 *
 */
public class ECourier {
	private int counterid;
	private String rname;
	private String address;
	private String city;
	private String pin;
	private String country;
	private String letter;
	private String logintype;
	public int getCounterid() {
		return counterid;
	}
	public void setCounterid(int counterid) {
		this.counterid = counterid;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getLetter() {
		return letter;
	}
	public void setLetter(String letter) {
		this.letter = letter;
	}
	public String getLogintype() {
		return logintype;
	}
	public void setLogintype(String logintype) {
		this.logintype = logintype;
	}

}
