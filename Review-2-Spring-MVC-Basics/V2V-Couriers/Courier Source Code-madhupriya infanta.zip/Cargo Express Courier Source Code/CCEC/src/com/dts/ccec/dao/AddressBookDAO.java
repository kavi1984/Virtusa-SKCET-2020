/**
 * 
 */
package com.dts.ccec.dao;

import com.dts.core.dao.AbstractDataAccessObject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.dts.ccec.model.AddressBook;
import com.dts.ccec.model.Sample;
import com.dts.core.dao.AbstractDataAccessObject;
import com.dts.core.util.CoreHash;
import com.dts.core.util.DateWrapper;
import com.dts.core.util.LoggerManager;


/**
 * @author dts0801010
 *
 */
public class AddressBookDAO extends AbstractDataAccessObject {
	Connection con;
	AddressBook aBook;
	public AddressBookDAO()
	{
		//con = getConnection();
	}
	//
	public boolean addAddress(AddressBook aBook)
	{
		PreparedStatement st;
		boolean flag = false;
		try {
			 con = getConnection();
			 st = con.prepareStatement("insert into addressBook values(?,?,?,?,?,?,?,?,?,?,?)");
			 int no=getSequenceID("addressbook","consigneeID");
			 st.setInt(1,no);
			 st.setString(2,aBook.getAname());
             st.setString(3,aBook.getHno());
             st.setString(4,aBook.getStreet());
             st.setString(5,aBook.getCity());
             st.setString(6,aBook.getPin());
             st.setString(7,aBook.getState());
             st.setString(8,aBook.getCountry());
             st.setString(9,aBook.getPhno());
             st.setString(10,aBook.getEmail());
             st.setString(11,aBook.getLogintype());
             int i = st.executeUpdate();
                  if(i==1)
                    {
                        flag=true;
             
                    }
                    else
                    {
                        flag=false;
             
                    }
             
        
		}
		catch(Exception e)
		{e.printStackTrace();
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		return flag;
	}
	
	//
	public void updateAddress(AddressBook aBook)
	{
		
	}
	
	//
	public boolean deleteAddress(String s)
	{
		boolean flag = false;
		try{
			con = getConnection();
            PreparedStatement st = con.prepareStatement("delete from addressBook where aname=?");
            st.setString(1,s);
            int i = st.executeUpdate();
            
            if(i>0)
           	 flag = true;
         
            }
		catch(Exception e)
		{
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		return flag;
	}
	
	//
	public AddressBook viewAddress(String s)
	{
		Statement st;
		try {
			con = getConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from addressBook where loginid = "+s);
			while(rs.next())
			{
				aBook = new AddressBook();
				aBook.setAname(rs.getString(2));
				aBook.setHno(rs.getString(3));
				aBook.setStreet(rs.getString(4));
				aBook.setCity(rs.getString(5));
				aBook.setPin(rs.getString(6));
				aBook.setState(rs.getString(7));
				aBook.setCountry(rs.getString(8));
				aBook.setPhno(rs.getString(9));
				aBook.setEmail(rs.getString(10));

				
			}
			
		
		} catch (SQLException e) {
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
        
		return aBook;
	}
	
	//
	public CoreHash listAddress(String loginid)
	{
		
		System.out.println("in list aBook");
		CoreHash aCoreHash = new CoreHash();
		aCoreHash.clear();
		System.out.println("aCoreHash--"+aCoreHash.isEmpty());
		int sno=1;
		Statement st;
		try {
			con = getConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from addressBook where loginid='"+loginid+"'");
			while(rs.next())
			{
				
				aBook = new AddressBook();
				aBook.setAname(rs.getString(2));
				aBook.setHno(rs.getString(3));
				aBook.setStreet(rs.getString(4));
				aBook.setCity(rs.getString(5));
				aBook.setPin(rs.getString(6));
				aBook.setState(rs.getString(7));
				aBook.setCountry(rs.getString(8));
				aBook.setPhno(rs.getString(9));
				aBook.setEmail(rs.getString(10));

				
				aCoreHash.put(new Integer(sno), aBook);
			    sno++;
			}
			
			
		} catch (SQLException e) {
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		
        
		return aCoreHash;
	}
	
}