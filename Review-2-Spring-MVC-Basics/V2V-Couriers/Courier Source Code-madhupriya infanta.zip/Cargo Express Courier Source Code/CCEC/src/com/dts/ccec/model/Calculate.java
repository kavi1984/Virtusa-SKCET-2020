package com.dts.ccec.model;

public class Calculate {
    float servicetax,amount;
 public float getServiceTax(int setv,float amt)
 {servicetax=(amt*setv)/100;
	 
	 return servicetax;
 }
 float cesstax;
  public float getCessTax(float tax,float amt)
 {
	cesstax=(amt*tax)/100;
	return cesstax;
 }
  
}
