package com.dts.ccec.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.dts.ccec.model.Feedback;
import com.dts.core.dao.AbstractDataAccessObject;
import com.dts.core.util.CoreHash;
import com.dts.core.util.LoggerManager;


/**
 * @author dts0801010
 *
 */
public class FeedBackDAO extends AbstractDataAccessObject {
	Connection con;
	Feedback feedback;
	public FeedBackDAO()
	{
		//con = getConnection();
	}
	//
	public boolean addFeedback(Feedback feedback)
	{
		PreparedStatement st;
		boolean flag = false;
		try {
			 con = getConnection();
			 st = con.prepareStatement("insert into feedback values(?,?,?,?,?,?,?,?,?)");
            int no=getSequenceID("feedback","feedbackid");
			 st.setInt(1,no);
             st.setString(2,feedback.getFeedBack());
             st.setString(3,feedback.getFname());
             st.setString(4,feedback.getEmail());
             st.setString(5,feedback.getAddress());
             
             st.setString(6,feedback.getCity());
             st.setString(7,feedback.getPin());
             st.setString(8,feedback.getCountry());
             st.setString(9,feedback.getOccupation());
           
             int i = st.executeUpdate();
             con.commit();
             if(i>0)
            	 flag = true;
        
		}
		catch(Exception e)
		{e.printStackTrace();
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		return flag;
	}
	
	//
	public void updateFeedback(Feedback feedback)
	{
		
	}
	
	//
	public boolean deleteFeedback(int s)
	{
		boolean flag = false;
		try{
			con = getConnection();
            PreparedStatement st = con.prepareStatement("delete from feedback where eCounterid=?");
            st.setInt(1,s);
            int i = st.executeUpdate();
            
            if(i>0)
           	 flag = true;
         
            }
		catch(Exception e)
		{
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		return flag;
	}
	
	//
	public Feedback viewFeedback(int s)
	{
		Statement st;
		try {
			con = getConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from feedback where feedbackid= "+s);
			while(rs.next())
			{
				feedback = new Feedback();
				feedback.setFeedbackId(s);
				feedback.setFeedBack(rs.getString(2));
				feedback.setFname(rs.getString(3));
				feedback.setEmail(rs.getString(4));
				feedback.setAddress(rs.getString(5));
				feedback.setCity(rs.getString(6));
				feedback.setPin(rs.getString(7));
				feedback.setCountry(rs.getString(8));
				feedback.setOccupation(rs.getString(9));
				
			}
			
		
		} catch (SQLException e) {
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
        
		return feedback;
	}
	
	//
	public CoreHash listfeedback()
	{
		
		System.out.println("in list feedback");
		CoreHash aCoreHash = new CoreHash();
		aCoreHash.clear();
		System.out.println("aCoreHash--"+aCoreHash.isEmpty());
		int sno=1;
		Statement st;
		try {
			con = getConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from feedback");
			while(rs.next())
			{
				
				feedback = new Feedback();
				feedback.setFeedbackId(rs.getInt(1));
				feedback.setFeedBack(rs.getString(2));
				feedback.setFname(rs.getString(3));
				feedback.setEmail(rs.getString(4));
				feedback.setAddress(rs.getString(5));
				feedback.setCity(rs.getString(6));
				feedback.setPin(rs.getString(7));
				feedback.setCountry(rs.getString(8));
				
				aCoreHash.put(new Integer(sno), feedback);
			    sno++;
			}
			
			
		} catch (SQLException e) {
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		
        
		return aCoreHash;
	}
	
}