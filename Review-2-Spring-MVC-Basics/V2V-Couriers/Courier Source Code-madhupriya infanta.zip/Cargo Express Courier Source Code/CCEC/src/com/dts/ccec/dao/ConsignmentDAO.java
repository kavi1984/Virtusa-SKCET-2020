/**
 * 
 */
package com.dts.ccec.dao;

import com.dts.core.dao.AbstractDataAccessObject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.dts.ccec.model.AddressBook;
import com.dts.ccec.model.Sample;
import com.dts.core.dao.AbstractDataAccessObject;
import com.dts.core.util.CoreHash;
import com.dts.core.util.DateWrapper;
import com.dts.core.util.LoggerManager;
import com.dts.dae.model.Profile;

/**
 * @author dts0801010
 *
 */
public class ConsignmentDAO extends AbstractDataAccessObject {
    Connection con;
	public int addCosignment(AddressBook aBook)
	{
		PreparedStatement st;
		int consignid=0;
		try {
			 con = getConnection();
			 String newdate=DateWrapper.parseDate(new Date());
            	 st=con.prepareStatement("insert into consignment values(?,?,?,?,?,?,?,?,?,?,?,?)");
            	 int no1=getSequenceID("consignment","consignID");
    			 st.setInt(1,no1);
    			 st.setString(2,aBook.getAname());
    			 String address=aBook.getHno()+","+aBook.getStreet()+","+aBook.getCity();
    			 st.setString(3,address);
    			 String stateCountry=aBook.getState()+","+aBook.getCountry();
    			 st.setString(4, stateCountry);
    			 st.setString(5,aBook.getPin());
    			 st.setString(6,aBook.getLogintype());
    			 st.setString(7,null);
    			 st.setString(8,newdate);
    			 st.setString(9, newdate);
    			 st.setInt(10,aBook.getWeigth());
    			 st.setInt(11,aBook.getNoofpeacec());
    			 st.setString(12,aBook.getContent());
                  int i=st.executeUpdate();
                    if(i==1)
                        consignid=no1;
                
                   
        
		}
		catch(Exception e)
		{e.printStackTrace();
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		return consignid;
	}
	public boolean updateCosignment(int conid)
	{
		PreparedStatement st;
		boolean flag=false;
		try {
			 con = getConnection();
			   
			   String newdate=DateWrapper.parseDate(new Date());
            	 st=con.prepareStatement("update consignment set status=?,sendDate=? where consignid="+conid);
            	 st.setString(1,"sended");
            	 st.setString(2,newdate);
            	 int i=st.executeUpdate();
                    if(i==1)
                        flag=true;
                    else
                    	flag=false;
                    
        
		}
		catch(Exception e)
		{e.printStackTrace();
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		return flag;
	}
	public AddressBook getCosignment(int conid)
	{
		Statement st;
		AddressBook aBook=null;
		try {
			 con = getConnection();
			   
			
            	 st=con.createStatement();
            	 ResultSet rs=st.executeQuery("select cname,address,country,pin,status,consigndate,sendDate,weigth,noofpeaces,content from consignment where consignid="+conid);
            	 if(rs.next())
                 {System.out.println(" in getprofile  ");
              	   aBook=new AddressBook();
              	   aBook.setAname(rs.getString(1));
              	   aBook.setAddress(rs.getString(2));
              	   aBook.setCountry(rs.getString(3));
              	   aBook.setPin(rs.getString(4));
              	   aBook.setStatus(rs.getString(5));
              	   aBook.setConsignDate(rs.getString(6));
              	   aBook.setSendDate(DateWrapper.parseDate(rs.getDate(7)).trim());
              	   aBook.setWeigth(rs.getInt(8));
              	   aBook.setNoofpeacec(rs.getInt(9));
              	   aBook.setContent(rs.getString(10));                 }
		}
		catch(Exception e)
		{e.printStackTrace();
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		return aBook;
	}
	//
	public CoreHash getAllCosignment()
	{CoreHash aCoreHash = new CoreHash();
	aCoreHash.clear();
	System.out.println("aCoreHash--"+aCoreHash.isEmpty());
	int sno=1;
	Statement st;
	AddressBook aBook=null;	try {
			 con = getConnection();
			   
			
            	 st=con.createStatement();
            	 ResultSet rs=st.executeQuery("select cname,address,country,pin,status,consigndate,sendDate,weigth,noofpeaces,content,consignID from consignment");
            	while(rs.next())
                 {System.out.println(" in getprofile  ");
              	   aBook=new AddressBook();
              	   aBook.setAname(rs.getString(1));
              	   aBook.setAddress(rs.getString(2));
              	   aBook.setCountry(rs.getString(3));
              	   aBook.setPin(rs.getString(4));
              	   aBook.setStatus(rs.getString(5));
              	   aBook.setConsignDate(rs.getString(6));
              	   aBook.setSendDate(DateWrapper.parseDate(rs.getDate(7)).trim());
              	   aBook.setWeigth(rs.getInt(8));
              	   aBook.setNoofpeacec(rs.getInt(9));
              	   aBook.setContent(rs.getString(10)); 
              	   aBook.setConsignID(rs.getInt(11));
              	 aCoreHash.put(new Integer(sno),aBook);
  			    sno++;
                 }
		}
		catch(Exception e)
		{e.printStackTrace();
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		return aCoreHash;
	}
	public CoreHash getCosigReport(String sdate,String edate)
	{
		
		
		CoreHash aCoreHash = new CoreHash();
		aCoreHash.clear();
		System.out.println("aCoreHash--"+aCoreHash.isEmpty());
		int sno=1;
		Statement st;
		AddressBook aBook=null;
		try {
			 con = getConnection();
			   
			
            	 st=con.createStatement();
            	 ResultSet rs=st.executeQuery("select country,weigth,noofpeaces,content,consignID,status from consignment where 'consigndate>=#"+sdate+" and consigndate<=#"+edate+"'");
            	 while(rs.next())
                 {
              	   aBook=new AddressBook();
              	   aBook.setCountry(rs.getString(1));
              	   aBook.setWeigth(rs.getInt(2));
              	   aBook.setNoofpeacec(rs.getInt(3));
              	   aBook.setContent(rs.getString(4));  
              	   aBook.setConsignID(rs.getInt(5));
              	 aBook.setStatus(rs.getString(6));
              	 aCoreHash.put(new Integer(sno),aBook);
 			    sno++;
 		  
                 }
		}
		catch(Exception e)
		{e.printStackTrace();
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		return aCoreHash;
	}

}
