package com.dts.core.model;


public class AbstractDataObject{
	
	
}
