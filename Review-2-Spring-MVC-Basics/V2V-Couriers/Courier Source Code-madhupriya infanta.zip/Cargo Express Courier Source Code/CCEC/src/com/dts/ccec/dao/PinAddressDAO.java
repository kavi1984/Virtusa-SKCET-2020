/**
 * 
 */
package com.dts.ccec.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import com.dts.ccec.model.PinAddress;
import com.dts.core.dao.AbstractDataAccessObject;
import com.dts.core.util.CoreHash;
import com.dts.core.util.LoggerManager;

/**
 * @author dts0801010
 *
 */
public class PinAddressDAO extends AbstractDataAccessObject {

public PinAddressDAO()
{
}
//
Connection con;
public boolean addPinAddress(PinAddress pAddress)
{
	PreparedStatement st;
    boolean flag = false;
	try {
		 con = getConnection();
		 st = con.prepareStatement("insert into pinCodeAddress values(?,?,?,?,?)");
         st.setString(1,pAddress.getLocationName());
         st.setString(2,pAddress.getAddress());
         st.setString(3,pAddress.getPhno());
         st.setString(4,pAddress.getEmail());
         st.setInt(5,pAddress.getPin());
         int i = st.executeUpdate();
         con.commit();
         if(i>0)
        	 flag = true;
    
	}
	catch(Exception e)
	{e.printStackTrace();
		LoggerManager.writeLogWarning(e);
	}
	finally
	{
	 try{
		 if(con!=null)
			 con.close();
		 
	 }
	 catch(Exception e){}
	}
	return flag;
}

//
public void updateAddress(PinAddress pAddress)
{
	
}

//
public boolean deleteAddress(String s)
{
	boolean flag = false;
	try{
		con = getConnection();
        PreparedStatement st = con.prepareStatement("delete from pincodeaddress where locationname=?");
        st.setString(1,s);
        int i = st.executeUpdate();
        
        if(i>0)
       	 flag = true;
     
        }
	catch(Exception e)
	{e.printStackTrace();
		LoggerManager.writeLogWarning(e);
	}
	finally
	{
	 try{
		 if(con!=null)
			 con.close();
		 
	 }
	 catch(Exception e){}
	}
	return flag;
}
PinAddress pAddress;
//
public PinAddress viewPinAddress(String s)
{
	Statement st;
	try {
		con = getConnection();
		st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from pincodeaddress where locationname ='"+s+"'");
		while(rs.next())
		{
			pAddress = new PinAddress();
			pAddress.setLocationName(rs.getString(1));
			pAddress.setAddress(rs.getString(2));
			pAddress.setPhno(rs.getString(3));
			pAddress.setEmail(rs.getString(4));
            pAddress.setPin(rs.getInt(5));
		}
		
	
	} catch (SQLException e) {
		LoggerManager.writeLogWarning(e);
	}
	finally
	{
	 try{
		 if(con!=null)
			 con.close();
		 
	 }
	 catch(Exception e){}
	}
    
	return pAddress;
}

//
public CoreHash listPinAddress(int pin)
{
	
	System.out.println("in list pAddress");
	CoreHash aCoreHash = new CoreHash();
	aCoreHash.clear();
	System.out.println("aCoreHash--"+aCoreHash.isEmpty());
	int sno=1;
	Statement st;
	try {
		con = getConnection();
		st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from pincodeaddress where pin="+pin);
		while(rs.next())
		{
			
			pAddress = new PinAddress();
			pAddress.setLocationName(rs.getString(1));
			pAddress.setAddress(rs.getString(2));
			pAddress.setPhno(rs.getString(3));
			pAddress.setEmail(rs.getString(4));
            pAddress.setPin(rs.getInt(5));
			aCoreHash.put(new Integer(sno), pAddress);
		    sno++;
		}
		
		
	} catch (SQLException e) {
		LoggerManager.writeLogWarning(e);
	}
	finally
	{
	 try{
		 if(con!=null)
			 con.close();
		 
	 }
	 catch(Exception e){}
	}
	
    
	return aCoreHash;
}

}
