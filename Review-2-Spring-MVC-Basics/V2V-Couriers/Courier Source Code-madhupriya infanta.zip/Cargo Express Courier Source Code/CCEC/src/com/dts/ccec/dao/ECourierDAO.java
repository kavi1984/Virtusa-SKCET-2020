/**
 * 
 */
package com.dts.ccec.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.dts.ccec.model.ECourier;
import com.dts.ccec.model.Sample;
import com.dts.core.dao.AbstractDataAccessObject;
import com.dts.core.util.CoreHash;
import com.dts.core.util.LoggerManager;


/**
 * @author dts0801010
 *
 */
public class ECourierDAO extends AbstractDataAccessObject {
	Connection con;
	ECourier eCourier;
	public ECourierDAO()
	{
		//con = getConnection();
	}
	//
	public boolean addECourier(ECourier eCourier)
	{
		PreparedStatement st;
		boolean flag = false;
		try {
			 con = getConnection();
			 st = con.prepareStatement("insert into ECourier values(?,?,?,?,?,?,?,?)");
            int no=getSequenceID("ecourier","ecourierid");
			 st.setInt(1,no);
             st.setString(2,eCourier.getRname());
             st.setString(3,eCourier.getAddress());
             st.setString(4,eCourier.getCity());
             st.setString(5,eCourier.getPin());
             st.setString(6,eCourier.getCountry());
             st.setString(7,eCourier.getLetter());
             st.setString(8,eCourier.getLogintype());
             int i = st.executeUpdate();
             con.commit();
             if(i>0)
            	 flag = true;
        
		}
		catch(Exception e)
		{e.printStackTrace();
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		return flag;
	}
	
	//
	public void updateECourier(ECourier eCourier)
	{
		
	}
	
	//
	public boolean deleteECourier(int s)
	{
		boolean flag = false;
		try{
			con = getConnection();
            PreparedStatement st = con.prepareStatement("delete from ECourier where eCounterid=?");
            st.setInt(1,s);
            int i = st.executeUpdate();
            
            if(i>0)
           	 flag = true;
         
            }
		catch(Exception e)
		{
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		return flag;
	}
	
	//
	public ECourier viewECourier(int s)
	{
		Statement st;
		try {
			con = getConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from ECourier where ecounterid= "+s);
			while(rs.next())
			{
				eCourier = new ECourier();
				eCourier.setCounterid(s);
				eCourier.setRname(rs.getString(2));
				eCourier.setAddress(rs.getString(3));
				eCourier.setCity(rs.getString(4));
				eCourier.setPin(rs.getString(5));
				eCourier.setCountry(rs.getString(6));
				eCourier.setLetter(rs.getString(7));
				eCourier.setLogintype(rs.getString(8));

				
			}
			
		
		} catch (SQLException e) {
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
        
		return eCourier;
	}
	
	//
	public CoreHash listECourier(String loginid)
	{
		
		System.out.println("in list eCourier");
		CoreHash aCoreHash = new CoreHash();
		aCoreHash.clear();
		System.out.println("aCoreHash--"+aCoreHash.isEmpty());
		int sno=1;
		Statement st;
		try {
			con = getConnection();
			st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from ECourier where loginid='"+loginid+"'");
			while(rs.next())
			{
				
				eCourier = new ECourier();
				eCourier.setCounterid(rs.getInt(1));
				eCourier.setRname(rs.getString(2));
				eCourier.setAddress(rs.getString(3));
				eCourier.setCity(rs.getString(4));
				eCourier.setPin(rs.getString(5));
				eCourier.setCountry(rs.getString(6));
				eCourier.setLetter(rs.getString(7));
				eCourier.setLogintype(rs.getString(8));
				
				aCoreHash.put(new Integer(sno), eCourier);
			    sno++;
			}
			
			
		} catch (SQLException e) {
			LoggerManager.writeLogWarning(e);
		}
		finally
		{
		 try{
			 if(con!=null)
				 con.close();
			 
		 }
		 catch(Exception e){}
		}
		
        
		return aCoreHash;
	}
	
}