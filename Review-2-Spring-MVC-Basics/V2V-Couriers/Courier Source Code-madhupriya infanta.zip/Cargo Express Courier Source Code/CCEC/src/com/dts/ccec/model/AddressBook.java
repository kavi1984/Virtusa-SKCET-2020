package com.dts.ccec.model;

public class AddressBook {
    //consign feeilds
	private String address;
    private String status;
    private String consignDate;
    private String sendDate;
    private int weigth;
    private int noofpeacec;
    private String content;
    private int consignID;
    
    
    private String logintype;   
	private String aname;
	private String hno;
	private String street;
	private String city;
	private String pin;
	private String state;
	private String country;
	private String phno;
	private String email;
	public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public String getHno() {
		return hno;
	}
	public void setHno(String hno) {
		this.hno = hno;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPhno() {
		return phno;
	}
	public void setPhno(String phno) {
		this.phno = phno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLogintype() {
		return logintype;
	}
	public void setLogintype(String logintype) {
		this.logintype = logintype;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getConsignDate() {
		return consignDate;
	}
	public void setConsignDate(String consignDate) {
		this.consignDate = consignDate;
	}
	public String getSendDate() {
		return sendDate;
	}
	public void setSendDate(String sendDate) {
		this.sendDate = sendDate;
	}
	public int getWeigth() {
		return weigth;
	}
	public void setWeigth(int weigth) {
		this.weigth = weigth;
	}
	public int getNoofpeacec() {
		return noofpeacec;
	}
	public void setNoofpeacec(int noofpeacec) {
		this.noofpeacec = noofpeacec;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getConsignID() {
		return consignID;
	}
	public void setConsignID(int consignID) {
		this.consignID = consignID;
	}
}
