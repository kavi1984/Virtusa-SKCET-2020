package com.dts.core.util;

import java.util.Vector;

public class CoreList extends Vector
{

}
