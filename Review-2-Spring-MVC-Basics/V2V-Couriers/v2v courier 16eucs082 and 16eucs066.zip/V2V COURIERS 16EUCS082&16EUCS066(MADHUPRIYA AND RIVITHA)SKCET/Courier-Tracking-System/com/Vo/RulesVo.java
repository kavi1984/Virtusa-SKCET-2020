package com.Vo;

public class RulesVo {
private int number;
private String rule;
private int status;
public int getStatus() {
	return status;
}
public void setStatus(int status) {
	this.status = status;
}
public int getNumber() {
	return number;
}
public void setNumber(int number) {
	this.number = number;
}
public String getRule() {
	return rule;
}
public void setRule(String rule) {
	this.rule = rule;
}
}
