package login.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

	@RequestMapping("/")
	public ModelAndView enter() {
	return new ModelAndView("home");
	}
	@RequestMapping("/home")
	public ModelAndView login(HttpServletRequest req , HttpServletResponse res) throws IOException{
	return new ModelAndView("home");
	}
	    
	    @RequestMapping("/check")
	    public ModelAndView check(HttpServletRequest req, HttpServletResponse res) {
	    try{
	       String username =req.getParameter("username"); 
	       String Phonenumber =req.getParameter("Phonenumber"); 
	       String email =req.getParameter("email"); 
	       String Profession =req.getParameter("Profession"); 
	       String password = req.getParameter("password");
	       Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
	       Connection conn=DriverManager.getConnection(  
	        "jdbc:mysql://localhost:3306/logins","root","Mysql123*");
	       
	       PreparedStatement pst = conn.prepareStatement("Select user,password from logins.login");
	       ResultSet rs = pst.executeQuery();
	       while(rs.next()){
	        if (rs.getString("user").equals(username)){
	        return new ModelAndView("alertOfExisting");
	        }
	       }
	       pst = conn.prepareStatement("INSERT INTO logins.login (user,password,Phonenumber,email,Profession)VALUES (?,?,?,?,?)");
	       pst.setString(1, username);
	       pst.setString(3, Phonenumber);
	       pst.setString(4, email);
	       pst.setString(5, Profession);
	       pst.setString(2, password);
	       System.out.print(Profession);
	       int n=pst.executeUpdate();
	    }
	       catch (Exception e) {
	System.out.print(e);
	}
	    return new ModelAndView("home");
	    }
	@RequestMapping(value="/validate")
	public ModelAndView test(HttpServletRequest req , HttpServletResponse res) throws IOException{
	try{
	       String username = req.getParameter("username");  
	       String password = req.getParameter("password");
	       Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
	       Connection conn=DriverManager.getConnection(  
	        "jdbc:mysql://localhost:3306/logins","root","Mysql123*");      
	       PreparedStatement pst = conn.prepareStatement("Select user,password from logins.login where user=? and password=?");
	       pst.setString(1, username);
	       pst.setString(2, password);
	       ResultSet rs = pst.executeQuery();    
	      
	       
	       if(rs.next()) {
	        return new ModelAndView("welcome");
	       }
	       
	       else {
	           return new ModelAndView("hello");
	           
	       }
	  }
	  catch(Exception e){      
	  System.out.print(e);
	  return new ModelAndView("home");
	  } 
	}
}

