package com.hello.v_academy__.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

	@RequestMapping(value="/")
	public ModelAndView test(HttpServletResponse response) throws IOException
	{
		return new ModelAndView("index");
	}
	
	
	@RequestMapping("/register")
    public ModelAndView register()
	{
    return new ModelAndView("register");
    }
	
	@RequestMapping("/check")
    public ModelAndView check(HttpServletRequest req, HttpServletResponse res) {
    try{
       String username =req.getParameter("username");  
       String password = req.getParameter("password");
       System.out.println(username);
       System.out.println(password);
       Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
       Connection conn=DriverManager.getConnection(  
        "jdbc:mysql://localhost:3306/learning_1","root","Hari@1999");
       
       PreparedStatement pst = conn.prepareStatement("Select user_id,password from learning_1.user");
       ResultSet rs = pst.executeQuery();
       while(rs.next()){
        if (rs.getString("user_id").equals(username)){
       
        return new ModelAndView("user_exists");
        }
       
       }
       pst = conn.prepareStatement("insert into learning_1.user(user_id,password)values (?,?)");
       pst.setString(1, username);
       pst.setString(2, password);
       int n=pst.executeUpdate();
       }
       
   
       catch (Exception e) {
    	   System.out.print(e);
       }
    	   return new ModelAndView("success_register");
	
}
   
	@RequestMapping("/validate")
	public ModelAndView test(HttpServletRequest req , HttpServletResponse res) throws IOException{
	try{
	       String username = req.getParameter("username");  
	       String password = req.getParameter("password");
	       System.out.println(username);
	       System.out.println(password);
	       Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
	       Connection conn=DriverManager.getConnection(  
	        "jdbc:mysql://localhost:3306/learning_1","root","Hari@1999");      
	       PreparedStatement pst = conn.prepareStatement("Select user_id,password from learning_1.user where user_id=? and password=?");
	       pst.setString(1, username);
	       pst.setString(2, password);
	       ResultSet rs = pst.executeQuery();    
	       
	       if(rs.next()) {
	        return new ModelAndView("welcome");
	       }
	       
	       else {
	    	   
	           return new ModelAndView("invalid_user");
	           
	       }
	  }
	  catch(Exception e){      
	  System.out.print(e);
	  
	  return new ModelAndView("invalid_user");
	       
	  }
	}
}
